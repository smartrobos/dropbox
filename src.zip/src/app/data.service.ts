import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {


  rawData: any = {}
  rawData1: any = {
    0 : [
          {
            nodeId : 1,
            detailRow : true,
            name: 'ES',
            coverage: '100%',
            pass: '98%',
            fail: '2%',
            type: 'Folder',
          },
          {
            nodeId : 2,
            detailRow : true,
            name: 'FC',
            coverage: '100%',
            pass: '100%',
            fail: '5%',
          },
          {
            nodeId : 3,
            detailRow : true,
            name: 'CS',
            coverage: '100%',
            pass: '80%',
            fail: '5%',
          }
        ]
  };

  constructor(
    public http: HttpClient
  ) {
    this.getRootData();
  }

  getRootData() {
    // Assume Root Data key is 0
    this.httpRequest(0);
  }
  getChildrenData(nodeId: number) {
    this.httpRequest(nodeId);
  }

  httpRequest(nodeId: number) {
    const url = `http://localhost:4000/${nodeId}`;
    this.http.get<any>(url).subscribe( data => {
          this.rawData[nodeId] = data;
          console.log('Log new rawData: ', data);
          console.log('Overall Raw data: ', this.rawData);
      }
    );
  }
}
