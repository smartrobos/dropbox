import { Component, OnInit, Input, ViewChild } from '@angular/core';
import {animate, state, style, transition, trigger} from '@angular/animations';
import { DataService } from '../data.service';
import { MatPaginator, MatSort, MatTable } from '@angular/material';
import { MatTableDataSource } from './mat-table-datasource';

@Component({
  selector: 'app-mat-table-item',
  templateUrl: './mat-table-item.component.html',
  styleUrls: ['./mat-table-item.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0', display: 'none'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})

export class MatTableItemComponent implements OnInit {

  @Input() key ;
  rawData: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('table') table: MatTable<any>;

  // tslint:disable-next-line:variable-name
  @Input() set data(_data: any) {
   // console.log('Input table data: ', _data);
    if (_data) {
    //  console.log('Key: ', this.key);
     // this.dataSource = _data[this.key];
      this.rawData = _data;
      this.dataSource = new MatTableDataSource(
        this.paginator,
        _data[this.key],
        this.sort
      );
    }
  }


// tslint:disable-next-line: no-use-before-declare
  dataSource: any;
//  columnsToDisplay = ['name', 'weight', 'symbol', 'position'];
  columnsToDisplay = ['name', 'coverage', 'pass', 'fail']; // Take input this also.
  expandedElement: any | null;

  constructor(
    public dataService: DataService
    ) {
      this.dataService.rawData.subscribe( data => {
        this.rawData = data;
        if(this.table.dataSource) {
          this.table.dataSource = data;
          this.table.renderRows();
        }
//        this.dataSource.data = data;
      });
  }

  ngOnInit() {
  }

  isExpansionDetailRow = (i: number, row: object) => {
    // console.log('index and Row: ', i, row, row.hasOwnProperty('detailRow'));
    return row.hasOwnProperty('detailRow');
  }

  isContainingChildren(row: object) {
    const hasDetailRow = row.hasOwnProperty('detailRow');
    return hasDetailRow;
  }

  /**
   * expand collapse a row
   * @param row
   */
  toggleRow(row) {
    if (this.expandedElement === row) {
      this.expandedElement = null;
    } else {
      this.expandedElement = row;
      console.log('Expanded Element ', row);
      this.dataService.getChildrenData(row.nodeId);
    }
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue;
  }
}
