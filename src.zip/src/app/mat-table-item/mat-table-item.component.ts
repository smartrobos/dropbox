import { Component, OnInit, Input } from '@angular/core';
import {animate, state, style, transition, trigger} from '@angular/animations';
import { DataService } from '../data.service';

@Component({
  selector: 'app-mat-table-item',
  templateUrl: './mat-table-item.component.html',
  styleUrls: ['./mat-table-item.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0', display: 'none'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})

export class MatTableItemComponent implements OnInit {

  @Input() key ;
  rawContent: any;



  // tslint:disable-next-line:variable-name
  @Input() set data(_data: any) {
   // console.log('Input table data: ', _data);
    if (_data) {
    //  console.log('Key: ', this.key);
      this.dataSource = _data[this.key];
      this.rawContent = _data;
    }
  }


// tslint:disable-next-line: no-use-before-declare
//  dataSource = ELEMENT_DATA;
  dataSource: any;
//  columnsToDisplay = ['name', 'weight', 'symbol', 'position'];
  columnsToDisplay = ['name', 'coverage', 'pass', 'fail']; // Take input this also.
  // expandedElement: PeriodicElement | null;
  expandedElement: any | null;

  constructor(
    public dataService: DataService
    ) {
    this.rawContent = dataService.rawData;
  }

  ngOnInit() {
  }

  isExpansionDetailRow = (i: number, row: object) => {
    // console.log('index and Row: ', i, row, row.hasOwnProperty('detailRow'));
    return row.hasOwnProperty('detailRow');
  }

  isContainingChildren(row: object) {
    const hasDetailRow = row.hasOwnProperty('detailRow');
    return hasDetailRow;
  }

  /**
   * expand collapse a row
   * @param row
   */
  toggleRow(row) {
    if (this.expandedElement === row) {
      this.expandedElement = null;
    } else {
      this.expandedElement = row;
      console.log('Expanded Element ', row);
      this.dataService.getChildrenData(row.nodeId);
    }
  }
}
