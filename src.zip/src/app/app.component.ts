import { Component } from '@angular/core';
import { DataService } from './data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'nested-mat-table';
  //  tableData = ELEMENT_DATA;
// tslint:disable-next-line: no-use-before-declare
  tableData : any;
  constructor(
    public dataService: DataService
    ) {
  //  this.dataService.getRootData();
    this.tableData = this.dataService.rawData;
  }
}

const data1: any = {
  0 : [
        {
          nodeId : 1,
          detailRow : true,
          name: 'ES',
          coverage: '100%',
          pass: '98%',
          fail: '2%',
          type: 'Folder',
        },
        {
          nodeId : 2,
          detailRow : true,
          name: 'FC',
          coverage: '100%',
          pass: '100%',
          fail: '5%',
        },
        {
          nodeId : 3,
          detailRow : true,
          name: 'CS',
          coverage: '100%',
          pass: '80%',
          fail: '5%',
        }
      ],
    1 : [
    {
      nodeId : 11,
      detailRow : true,
      name: 'Legacy',
      coverage: '100%',
      pass: '98%',
      fail: '2%',
      type: 'Folder',
    }
  ],
  2 : [
    {
      nodeId : 21,
      detailRow : true,
      name: 'Legacy',
      coverage: '100%',
      pass: '98%',
      fail: '2%',
      type: 'Folder',
    },
    {
      nodeId : 22,
      detailRow : true,
      name: 'NewFeatures',
      coverage: '100%',
      pass: '100%',
      fail: '5%',
    }
  ],
  3 : [
    {
      nodeId : 31,
      detailRow : true,
      name: 'Legacy',
      coverage: '100%',
      pass: '98%',
      fail: '2%',
      type: 'Folder',
    },
    {
      nodeId : 32,
      detailRow : true,
      name: 'NewFeatures',
      coverage: '100%',
      pass: '100%',
      fail: '5%',
    }
  ],
  11:  [
    {
      nodeId : 111,
      detailRow : true,
      name: 'Functional',
      coverage: '100%',
      pass: '98%',
      fail: '2%',
      type: 'Folder',
    },
    {
      nodeId : 112,
      detailRow : true,
      name: 'Performance',
      coverage: '100%',
      pass: '100%',
      fail: '5%',
    }
  ],
  21:  [
    {
      nodeId : 211,
      detailRow : true,
      name: 'Functional',
      coverage: '100%',
      pass: '98%',
      fail: '2%',
      type: 'Folder',
    },
    {
      nodeId : 212,
      detailRow : true,
      name: 'Performance',
      coverage: '100%',
      pass: '100%',
      fail: '5%',
    }
  ],
  22:  [
    {
      nodeId : 221,
      detailRow : true,
      name: 'Functional',
      coverage: '100%',
      pass: '98%',
      fail: '2%',
      type: 'Folder',
    },
    {
      nodeId : 222,
      detailRow : true,
      name: 'Performance',
      coverage: '100%',
      pass: '100%',
      fail: '5%',
    }
  ],
  31:  [
    {
      nodeId : 311,
      detailRow : true,
      name: 'Functional',
      coverage: '100%',
      pass: '98%',
      fail: '2%',
      type: 'Folder',
    },
    {
      nodeId : 312,
      detailRow : true,
      name: 'Performance',
      coverage: '100%',
      pass: '100%',
      fail: '5%',
    }
  ],
  32:  [
    {
      nodeId : 321,
      detailRow : true,
      name: 'Functional',
      coverage: '100%',
      pass: '98%',
      fail: '2%',
      type: 'Folder',
    },
    {
      nodeId : 322,
      detailRow : true,
      name: 'Performance',
      coverage: '100%',
      pass: '100%',
      fail: '5%',
    }
  ],
  211: [],
  212: [],
  221: [],
  222: [],
  311: [],
  312: [],
  321: [],
  322: []
};
