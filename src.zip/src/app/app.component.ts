import { Component } from '@angular/core';
import { DataService } from './data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'nested-mat-table';
  //  tableData = ELEMENT_DATA;
// tslint:disable-next-line: no-use-before-declare
  tableData : any;
  constructor(
    public dataService: DataService
    ) {
      this.dataService.rawData.subscribe( data => {
          this.tableData = data;
        });
    }
}
